$(equilibrateButton).click(function(e) {
  e.preventDefault();
  console.log("here forth");
  //labWage.setAttribute('x2', labWageLength+moveSize/2);
  //labEmp.setAttribute('y2', labEmpHeight-moveSize/2);

  TweenLite.to(labWage,2, {y: -moveSize/2, delay: 1});
  TweenLite.to(labEmp,2, {x: -moveSize/2, delay: 1});

  //TweenLite.to(indicatorMarkUp, 1, {attr:{cx:100}, delay: 1});
  TweenLite.to(labWage, 2, {attr:{x2:labWageLength+moveSize/2}, delay: 1});
  TweenLite.to(labEmp, 2, {attr:{y2:labEmpHeight-moveSize/2}, delay: 1});
  //labWage.setAttribute('y1', labWagePstn+x );
  //labWage.setAttribute('y2', labWagePstn+x );


  //labEmp.setAttribute('y2', labEmpHeight-x,);
  //labEmp.setAttribute('x1', labEmpPstn+x );
  //labEmp.setAttribute('x2', labEmpPstn+x );

});

(function($) {

	// JS code goes here
	//alert("I'm in src");



  var header = $('#header'),
    h1 = $('h1'),
    h2 = $('h2'),
    intro = $('.intro'), // . denotes a class name
    firstItem = $('li:first-child'), // li denotes a list item
    secondItem = $('li:nth-child(2)'),
    lastItem = $('li:last-child')
    img1 = $('#img1')
    redLine_x = 0;
    redLine_y = 0;



  //TweenLite.to(header,4,{opacity: 0, y: 50});
        //TweenLite.to(header,2,{opacity: 100, y: -50});

  var img=$('img');
  //TweenLite.to(img,1,{width:100, x: 200})
  //TweenLite.from(img,1,{x: -200, ease:Power1.easeOut})
  // -- TweenLite.from(img,1,{x: -200, ease:Back.easeOut})  // cannot use 'Power#'
  TweenLite.from(img,1,{x: -200, ease:Bounce.easeOut})  // cannot use 'Power#'
  // -- TweenLite.from(img,1,{x: -200, ease:Circ.easeOut})  // cannot use 'Power#'
  // -- TweenLite.from(img,1,{x: -200,ease:Elastic.easeOut})  // cannot use 'Power#'
  // -- TweenLite.from(img,1,{x: -200, ease:Expo.easeOut})  // cannot use 'Power#'
  // -- TweenLite.from(img,1,{x: -200, ease:Sine.easeOut})  // cannot use 'Power#'
  // -- TweenLite.from(img,1,{x: -200, ease:Back.easeOut})  // cannot use 'Power#'
  // -- TweenLite.from(img,1,{x: -200, ease:Back.easeOut})  // cannot use 'Power#'
  //TweenLite.from(img,1,{x: -200, ease:Stepped.easeOut})  // cannot use 'Power#'

  //TweenLite.fromTo(img,1, {x: -200});
  //TweenLite.set(img,{x: -200}, {x: 200});
  TweenLite.from(h2, 2, {autoAlpha: 0, delay: 1});

    // DGB figure
  TweenLite.from(img1,1,{autoAlpha: 0, x: -100, delay: 2})
  //TweenLite.from(path1,4,{autoAlpha: 0, x: -200, delay: 3})
  //TweenLite.from(path2,3,{autoAlpha: 0, x: -250, delay: 4})
  //TweenLite.from(path3,5,{autoAlpha: 0, x: 200, delay:5})
  //TweenLite.from(path4,2,{autoAlpha: 0, x: 100, delay: 6})
  ///TweenLite.from(path5,1,{autoAlpha: 0, x: 50, delay: 7})
  //TweenLite.from(redLine,5,{autoAlpha: 0, x: -200, delay: 12})
  //TweenLite.from(littleRedLine,4,{autoAlpha: 0, x: -400, y: 100, delay: 13})



  function dragReport(event) {
    console.log(event.type + ' ' + 'fired')
  }

  Draggable.create("#redLine", {
    type:"x",
    onDrag: function(event){
      dragReport(event);
      redLine_x = this.x;
      redLine_y = this.y;
      console.log("test1", this.x +' ' + this.y);
      console.log("redLine_x = ", redLine_x);
      TweenLite.to("#littleRedLine",1,{y: redLine_y, delay: 3})
    }
  })


  Draggable.create("#interestRate", {
    type:"y",
    onPress: function(event){
     //refreshGlobals();
    },
    onDrag: function(event){
      dragReport(event);
      change_x = this.x;  // x is a GSAP variable, in this case determined by the move in #interestRate.
      change_y = this.y;



      TweenLite.to(aggDem,0, {x: change_y, delay: 0, onComplete: changeLineLength(change_y)}); // x again is a GSAP variable, this time determining the consequent move of #aggregateDemand/     
 
      },
    })


function changeLineLength(x){
  moveSize = x;
  intRateMoveSize = x;
  //ISmoveSize = x;
  //x = x + ISmoveSize;
  console.log("intRateMoveSize = ", intRateMoveSize);
  //TweenLite.to(aggDem,1, {y2: aggDemHeight+x, delay: 1});
  aggDem.setAttribute('y2', aggDemHeight+x);
  intRate.setAttribute('x2', intRateLength+x);
  indicatorAggDemand.setAttribute('cx', indicatorAggDemandPstn+x);
  indicatorIndProd.setAttribute('cy', indicatorIndProdPstn-x);


  indProd.setAttribute('y1', indProdHeight-x,);
  indProd.setAttribute('y2', indProdHeight-x );
  indProd.setAttribute('x2', indProdLength+x );

  indProdLab.setAttribute('x1', indProdLabPstn+x,);
  indProdLab.setAttribute('x2', indProdLabPstn+x );
  indProdLab.setAttribute('y2', indProdLabHeight-x );

  phillipsWageInfl.setAttribute('y1', phillipsWageInflPstn-x,);
  phillipsWageInfl.setAttribute('y2', phillipsWageInflPstn-x );
  phillipsWageInfl.setAttribute('x2', phillipsWageInflLength+x );

  phillipsLab.setAttribute('x1', phillipsLabPstn+x,);
  phillipsLab.setAttribute('x2', phillipsLabPstn+x );
  phillipsLab.setAttribute('y2', phillipsLabHeight-x );

  phillipsCircle.setAttribute('cy', indicatorPhillipsPstn-x );
  markUpCircle.setAttribute('cx', indicatorMarkUpPstn+x );

  phillipsEmpCircle.setAttribute('cx', indicatorPhillipsEmpPstn+x );
  prodEmpCircle.setAttribute('cx', indicatorProdEmpPstn+x );
  labEmpCircle.setAttribute('cx', indicatorLabEmpPstn+x );


  markUpWageInfl.setAttribute('x1', markUpWageInflPstn+x,);
  markUpWageInfl.setAttribute('x2', markUpWageInflPstn+x );
  markUpWageInfl.setAttribute('y2', markUpWageInflHeight-x );

  markUpInfl.setAttribute('x2', markUpInflLength+x,);
  markUpInfl.setAttribute('y1', markUpInflPstn-x );
  markUpInfl.setAttribute('y2', markUpInflPstn-x );

  labDemand.setAttribute('x1', labDemandX1+x );
  labDemand.setAttribute('x2', labDemandX2+x );

  labWage.setAttribute('x2', labWageLength+x,);
  //labWage.setAttribute('y1', labWagePstn+x );
  //labWage.setAttribute('y2', labWagePstn+x );


  //labEmp.setAttribute('y2', labEmpHeight-x,);
  labEmp.setAttribute('x1', labEmpPstn+x );
  labEmp.setAttribute('x2', labEmpPstn+x );

  //refreshGlobals();
  }

  





//  Draggable.create("#IScurve", {
//    type:"x,y",
    //bounds:"#circle",
    //overshootTolerance:0,
    //throwProps:true
//  })

//  Draggable.create("#testLine", {
//    type:"y",
    //bounds:"#circle",
    //overshootTolerance:0,
    //throwProps:true
//  })

  Draggable.create("#path2", {
    type:"x,y",
    //bounds:"#circle",
    //overshootTolerance:0,
    //throwProps:true
  })

  Draggable.create("#path3", {
    type:"x,y",
    //bounds:"#circle",
    //overshootTolerance:0,
    //throwProps:true
  })

  Draggable.create("#path4", {
    type:"x,y",
    //bounds:"#circle",
    //overshootTolerance:0,
    //throwProps:true
  })

  Draggable.create("#path5", {
    type:"x,y",
    //bounds:"#circle",
    //overshootTolerance:0,
    //throwProps:true
  })


})(jQuery);

function refreshGlobals(){
console.log("1234 refresh globals");

moveSize = 0;
intRateMoveSize = 0;
ISmoveSize = 0;


equilibrateButton = $("#equilibrateButton");

addLength = 0;

aggDem = document.getElementById("aggregateDemand");
aggDemHeight = Number(aggDem.getAttribute('y2'));

console.log("aggDemHeight", aggDemHeight);

intRate = document.getElementById("interestRate");
intRateLength = Number(intRate.getAttribute('x2'));
indicatorAggDemand = document.getElementById("aggDemandCircle");
indicatorAggDemandPstn = Number(indicatorAggDemand.getAttribute('cx'));
indicatorIndProd = document.getElementById("indProdCircle");
indicatorIndProdPstn = Number(indicatorIndProd.getAttribute('cy'));
indProd = document.getElementById("indProdLine");
indProdHeight = Number(indProd.getAttribute('y2'));
indProdLength = Number(indProd.getAttribute('x2'));

indProdLab = document.getElementById("indProdLabLine");
indProdLabHeight = Number(indProdLab.getAttribute('y2'));
indProdLabPstn = Number(indProdLab.getAttribute('x1'));

phillipsLab = document.getElementById("phillipsLabLine");
phillipsLabHeight = Number(indProdLab.getAttribute('y2'));
phillipsLabPstn = Number(indProdLab.getAttribute('x1'));

phillipsWageInfl = document.getElementById("phillipsWageInflLine");
phillipsWageInflLength = Number(phillipsWageInfl.getAttribute('x2'));
phillipsWageInflPstn = Number(phillipsWageInfl.getAttribute('y1'));

indicatorPhillips = document.getElementById("phillipsCircle");
indicatorPhillipsPstn = Number(indicatorPhillips.getAttribute('cy'));


indicatorMarkUp = document.getElementById("markUpCircle");
indicatorMarkUpPstn = Number(indicatorMarkUp.getAttribute('cx'));

indicatorLabEmp = document.getElementById("labEmpCircle");
indicatorLabEmpPstn = Number(indicatorLabEmp.getAttribute('cx'));

indicatorPhillipsEmp = document.getElementById("phillipsEmpCircle");
indicatorPhillipsEmpPstn = Number(indicatorPhillipsEmp.getAttribute('cx'));

indicatorProdEmp = document.getElementById("prodEmpCircle");
indicatorProdEmpPstn = Number(indicatorProdEmp.getAttribute('cx'));


markUpWageInfl = document.getElementById("markUpWageInflLine");
markUpWageInflHeight = Number(markUpWageInfl.getAttribute('y2'));
markUpWageInflPstn = Number(markUpWageInfl.getAttribute('x1'));

markUpInfl = document.getElementById("markUpInflLine");
markUpInflLength = Number(markUpInfl.getAttribute('x2'));
markUpInflPstn = Number(markUpInfl.getAttribute('y2'));

labDemand = document.getElementById("labDemandCurve");
labDemandX1 = Number(labDemand.getAttribute('x1'));
labDemandX2 = Number(labDemand.getAttribute('x2'));

labWage = document.getElementById("labWageLine");
labWagePstn = Number(labWage.getAttribute('y1'));
labWageLength = Number(labWage.getAttribute('x2'));

labEmp = document.getElementById("labEmpLine");
labEmpPstn = Number(labEmp.getAttribute('x1'));
labEmpHeight = Number(labEmp.getAttribute('y2'));

equilibrateButton = document.getElementById("equilibrateButton");
}

