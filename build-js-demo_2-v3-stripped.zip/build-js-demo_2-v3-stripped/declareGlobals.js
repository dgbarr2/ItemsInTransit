var moveSize = 0;
var intRateMoveSize = 0;
var ISmoveSize = 0;


var equilibrateButton = $("#equilibrateButton");

var addLength = 0;

var aggDem = document.getElementById("aggregateDemand");
var aggDemHeight = Number(aggDem.getAttribute('y2'));

var intRate = document.getElementById("interestRate");
var intRateLength = Number(intRate.getAttribute('x2'));
var indicatorAggDemand = document.getElementById("aggDemandCircle");
var indicatorAggDemandPstn = Number(indicatorAggDemand.getAttribute('cx'));
var indicatorIndProd = document.getElementById("indProdCircle");
var indicatorIndProdPstn = Number(indicatorIndProd.getAttribute('cy'));
var indProd = document.getElementById("indProdLine");
var indProdHeight = Number(indProd.getAttribute('y2'));
var indProdLength = Number(indProd.getAttribute('x2'));

var indProdLab = document.getElementById("indProdLabLine");
var indProdLabHeight = Number(indProdLab.getAttribute('y2'));
var indProdLabPstn = Number(indProdLab.getAttribute('x1'));

var phillipsLab = document.getElementById("phillipsLabLine");
var phillipsLabHeight = Number(indProdLab.getAttribute('y2'));
var phillipsLabPstn = Number(indProdLab.getAttribute('x1'));

var phillipsWageInfl = document.getElementById("phillipsWageInflLine");
var phillipsWageInflLength = Number(phillipsWageInfl.getAttribute('x2'));
var phillipsWageInflPstn = Number(phillipsWageInfl.getAttribute('y1'));

var indicatorPhillips = document.getElementById("phillipsCircle");
var indicatorPhillipsPstn = Number(indicatorPhillips.getAttribute('cy'));


var indicatorMarkUp = document.getElementById("markUpCircle");
var indicatorMarkUpPstn = Number(indicatorMarkUp.getAttribute('cx'));

var indicatorLabEmp = document.getElementById("labEmpCircle");
var indicatorLabEmpPstn = Number(indicatorLabEmp.getAttribute('cx'));

var indicatorPhillipsEmp = document.getElementById("phillipsEmpCircle");
var indicatorPhillipsEmpPstn = Number(indicatorPhillipsEmp.getAttribute('cx'));

var indicatorProdEmp = document.getElementById("prodEmpCircle");
var indicatorProdEmpPstn = Number(indicatorProdEmp.getAttribute('cx'));


var markUpWageInfl = document.getElementById("markUpWageInflLine");
var markUpWageInflHeight = Number(markUpWageInfl.getAttribute('y2'));
var markUpWageInflPstn = Number(markUpWageInfl.getAttribute('x1'));

var markUpInfl = document.getElementById("markUpInflLine");
var markUpInflLength = Number(markUpInfl.getAttribute('x2'));
var markUpInflPstn = Number(markUpInfl.getAttribute('y2'));

var labDemand = document.getElementById("labDemandCurve");
var labDemandX1 = Number(labDemand.getAttribute('x1'));
var labDemandX2 = Number(labDemand.getAttribute('x2'));

var labWage = document.getElementById("labWageLine");
var labWagePstn = Number(labWage.getAttribute('y1'));
var labWageLength = Number(labWage.getAttribute('x2'));

var labEmp = document.getElementById("labEmpLine");
var labEmpPstn = Number(labEmp.getAttribute('x1'));
var labEmpHeight = Number(labEmp.getAttribute('y2'));

var equilibrateButton = document.getElementById("equilibrateButton");


