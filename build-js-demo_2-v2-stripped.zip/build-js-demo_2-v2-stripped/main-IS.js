
(function($) {

	// JS code goes here
	//alert("I'm in src");



  var header = $('#header'),
    h1 = $('h1'),
    h2 = $('h2'),
    intro = $('.intro'), // . denotes a class name
    firstItem = $('li:first-child'), // li denotes a list item
    secondItem = $('li:nth-child(2)'),
    lastItem = $('li:last-child')
    img1 = $('#img1')
    redLine_x = 0;
    redLine_y = 0;


  var img=$('img');
  TweenLite.from(img,1,{x: -200, ease:Bounce.easeOut})
  TweenLite.from(h2, 2, {autoAlpha: 0, delay: 1});

  TweenLite.from(img1,1,{autoAlpha: 0, x: -100, delay: 2})


  function dragReport(event) {
    console.log(event.type + ' ' + 'fired')
  }

  Draggable.create("#redLine", {
    type:"x",
    onDrag: function(event){
      dragReport(event);
      redLine_x = this.x;
      redLine_y = this.y;
      console.log("test1", this.x +' ' + this.y);
      console.log("redLine_x = ", redLine_x);
      TweenLite.to("#littleRedLine",1,{y: redLine_y, delay: 3})
    }
  })

  

  Draggable.create("#IScurve", {
    type:"x",
    onPress: function(event){
     refreshGlobals();
    },
    onDrag: function(event){
      dragReport(event);
      change_x = this.x;  // x is a GSAP variable, in this case determined by the move in #interestRate.

      TweenLite.to(aggDem,0, {x: change_x, delay: 0, onComplete: changeLineLength_IS(change_x)}); // x again is a GSAP variable, this time determining the consequent move of #aggregateDemand/     
      
      }
    })


function changeLineLength_IS(x){
  moveSize = x;
  //x = x + intRateMoveSize;
  aggDem.setAttribute('y2', aggDemHeight);
  intRate.setAttribute('x2', intRateLength+x);
  indicatorAggDemand.setAttribute('cx', indicatorAggDemandPstn+x);
  indicatorIndProd.setAttribute('cy', indicatorIndProdPstn-x);


  indProd.setAttribute('y1', indProdHeight-x,);
  indProd.setAttribute('y2', indProdHeight-x );
  indProd.setAttribute('x2', indProdLength+x );

  indProdLab.setAttribute('x1', indProdLabPstn+x,);
  indProdLab.setAttribute('x2', indProdLabPstn+x );
  indProdLab.setAttribute('y2', indProdLabHeight-x );

  phillipsWageInfl.setAttribute('y1', phillipsWageInflPstn-x,);
  phillipsWageInfl.setAttribute('y2', phillipsWageInflPstn-x );
  phillipsWageInfl.setAttribute('x2', phillipsWageInflLength+x );

  phillipsLab.setAttribute('x1', phillipsLabPstn+x,);
  phillipsLab.setAttribute('x2', phillipsLabPstn+x );
  phillipsLab.setAttribute('y2', phillipsLabHeight-x );

  phillipsCircle.setAttribute('cy', indicatorPhillipsPstn-x );
  markUpCircle.setAttribute('cx', indicatorMarkUpPstn+x );

  phillipsEmpCircle.setAttribute('cx', indicatorPhillipsEmpPstn+x );
  prodEmpCircle.setAttribute('cx', indicatorProdEmpPstn+x );
  labEmpCircle.setAttribute('cx', indicatorLabEmpPstn+x );


  markUpWageInfl.setAttribute('x1', markUpWageInflPstn+x,);
  markUpWageInfl.setAttribute('x2', markUpWageInflPstn+x );
  markUpWageInfl.setAttribute('y2', markUpWageInflHeight-x );

  markUpInfl.setAttribute('x2', markUpInflLength+x,);
  markUpInfl.setAttribute('y1', markUpInflPstn-x );
  markUpInfl.setAttribute('y2', markUpInflPstn-x );

  labDemand.setAttribute('x1', labDemandX1+x );
  labDemand.setAttribute('x2', labDemandX2+x );

  labWage.setAttribute('x2', labWageLength+x,);

  labEmp.setAttribute('x1', labEmpPstn+x );
  labEmp.setAttribute('x2', labEmpPstn+x );


  }

  



  Draggable.create("#path2", {
    type:"x,y",
    //bounds:"#circle",
    //overshootTolerance:0,
    //throwProps:true
  })

  Draggable.create("#path3", {
    type:"x,y",
    //bounds:"#circle",
    //overshootTolerance:0,
    //throwProps:true
  })

  Draggable.create("#path4", {
    type:"x,y",
    //bounds:"#circle",
    //overshootTolerance:0,
    //throwProps:true
  })

  Draggable.create("#path5", {
    type:"x,y",
    //bounds:"#circle",
    //overshootTolerance:0,
    //throwProps:true
  })


})(jQuery);
